#!/bin/bash
echo off
export __DIR_=$PWD
export __VERSION_="1.0.2"
export __NIKTOVERSION_="1.0.2"
export __SONAR_CLI_="11.3"
export NODE_ENV_VAL=$1
export __CLAM_VERSION_=1.4_base

#docker version > null 2>&1
rm -f .env

if [ -z "$NODE_ENV_VAL" ]; then
  export NODE_ENV_VAL=production
else
  export NODE_ENV_VAL=development
fi
echo __DIR_=$PWD >> .env
echo __VERSION_=$__VERSION_ >> .env
echo __NIKTOVERSION_=$__NIKTOVERSION_ >> .env
echo __SONAR_CLI_=$__SONAR_CLI_ >> .env
echo NODE_ENV=$NODE_ENV_VAL >> .env
echo __CLAM_VERSION_=$__CLAM_VERSION_ >> .env

#docker image prune -f 
#sysctl -w vm.max_map_count=524288
#sysctl -w fs.file-max=131072
#ulimit -n 131072
#ulimit -u 8192
docker network rm -f deepscan_ipv4
if docker info > /dev/null 2>&1; then
	echo 'Starting deepscan server. First time can take up to 10 minutes to start.'
	docker-compose down
	#docker rm --force ds-web ds-sonarqube ds-postgresql ds-adminer ds-sonarscan ds-zap ds-nmapscan ds-nikto ds-dc ds-zap-api ds-clam ds-clam-fresh
	
	if docker container inspect ds-web > /dev/null 2>&1; then 
		docker rm --force ds-web	
	fi
	if docker container inspect ds-sonarqube > /dev/null 2>&1; then 
		docker rm --force ds-sonarqube	
	fi
	if docker container inspect ds-postgresql > /dev/null 2>&1; then 
		docker rm --force ds-postgresql	
	fi
	if docker container inspect ds-adminer > /dev/null 2>&1; then 
		docker rm --force ds-adminer	
	fi

	if docker container inspect ds-sonarscan > /dev/null 2>&1; then 
		docker rm --force ds-sonarscan	
	fi

	if docker container inspect ds-zap > /dev/null 2>&1; then 
		docker rm --force ds-zap	
	fi

	if docker container inspect ds-nmapscan > /dev/null 2>&1; then 
		docker rm --force ds-nmapscan	
	fi

	if docker container inspect ds-nikto > /dev/null 2>&1; then 
		docker rm --force ds-nikto
	fi

	if docker container inspect ds-dc > /dev/null 2>&1; then 
		docker rm --force ds-dc
	fi

	if docker container inspect ds-zap-api > /dev/null 2>&1; then 
		docker rm --force ds-zap-api
	fi

	if docker container inspect ds-clam > /dev/null 2>&1; then 
		docker rm --force ds-clam	
	fi

	if docker container inspect ds-clam-fresh > /dev/null 2>&1; then 
		docker rm --force ds-clam-fresh	
	fi

	docker network rm -f deepscan_ipv4
	chmod -R 755 ./webserver/logs
	chmod +x stop.sh
cd ./webserver &&docker build -t deepscan/ds-webserver:$__VERSION_ . \
			&& cd ../postgres && docker build -t deepscan/ds-postgres:$__VERSION_ . \
			&& docker pull instrumentisto/nmap:7.95 && docker image tag instrumentisto/nmap:7.95 deepscan/ds-nmap:$__VERSION_ \
			&& docker pull clamav/clamav:$__CLAM_VERSION_ && docker image tag clamav/clamav:$__CLAM_VERSION_ deepscan/ds-clam:$__VERSION_ \
			&& docker pull toniblyx/prowler:5.7.3 && docker image tag toniblyx/prowler:5.7.3 deepscan/prowler:$__VERSION_ \
			&& cd ../zap && docker build -t deepscan/ds-zap:$__VERSION_ . \
			&& docker pull sonarsource/sonar-scanner-cli:$__SONAR_CLI_ \
			&& docker pull venkatrv75/nikto:$__NIKTOVERSION_ \
			&& cd ..
docker compose up --build
else 
    echo Is docker daemon running? Please start it first.
fi