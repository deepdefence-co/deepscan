echo off
export __DIR_=$PWD
export __VERSION_=1.0.2
export __NIKTOVERSION_=1.0.2
export __SONAR_CLI_=10.0
docker version > nul 2>&1

if [ $? == 0 ]; then 
	echo 'Starting deepscan server. First time can take up to 10 minutes to start.'
	docker-compose down
	echo $__VERSION_
	docker rm --force ds-web ds-sonarqube ds-postgresql ds-adminer ds-sonarscan ds-zap ds-nmapscan  ds-nikto ds-dc
cd ./webserver && docker build -t deepscan/ds-webserver:$__VERSION_ . \
			&& cd ../postgres && docker build -t deepscan/ds-postgres:$__VERSION_ . \
			&& docker pull instrumentisto/nmap:7.95 && docker image tag instrumentisto/nmap:7.95 deepscan/ds-nmap:$__VERSION_ \
			&& docker pull toniblyx/prowler:5.7.3 && docker image tag toniblyx/prowler:5.7.3 deepscan/prowler:$__VERSION_ \
			&& cd ../zap && docker build -t deepscan/ds-zap:$__VERSION_ . \
			&& docker pull sonarsource/sonar-scanner-cli:$__SONAR_CLI_ \
			&& docker pull venkatrv75/nikto:%__NIKTOVERSION_% \
			&& cd ..
docker-compose up --build
else 
    echo Is docker daemon running? Please start it first.
fi