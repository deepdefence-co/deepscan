#!/bin/bash
echo off
export __DIR_=$PWD
export __VERSION_="1.0.2"
export __NIKTOVERSION_="1.0.2"
export __SONAR_CLI_="10.0"
#docker version > null 2>&1


rm -f .env
echo __DIR_=$PWD >> .env
echo __VERSION_=$__VERSION_ >> .env
echo __NIKTOVERSION_=$__NIKTOVERSION_ >> .env
echo __SONAR_CLI_=$__SONAR_CLI_ >> .env

if ! docker info > /dev/null 2>&1; then
	echo 'Starting deepscan server. First time can take up to 10 minutes to start.'
	sudo docker-compose down
	echo $__VERSION_
	sudo docker rm --force ds-web ds-sonarqube ds-postgresql ds-adminer ds-sonarscan ds-zap ds-nmapscan  ds-nikto ds-dc
cd ./webserver &&sudo docker build -t deepscan/ds-webserver:$__VERSION_ . \
			&& cd ../postgres && sudo docker build -t deepscan/ds-postgres:$__VERSION_ . \
			&& sudo docker pull instrumentisto/nmap:7.95 &&sudo docker image tag instrumentisto/nmap:7.95 deepscan/ds-nmap:$__VERSION_ \
			&& sudo docker pull toniblyx/prowler:5.7.3 &&sudo docker image tag toniblyx/prowler:5.7.3 deepscan/prowler:$__VERSION_ \
			&& cd ../zap && sudo docker build -t deepscan/ds-zap:$__VERSION_ . \
			&& sudo docker pull sonarsource/sonar-scanner-cli:$__SONAR_CLI_ \
			&& sudo docker pull venkatrv75/nikto:%__NIKTOVERSION_% \
			&& cd ..
sudo docker-compose up --build
else 
    echo Is docker daemon running? Please start it first.
fi