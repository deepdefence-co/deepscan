sudo systemctl stop docker

sudo systemctl start docker

sudo snap start docker
