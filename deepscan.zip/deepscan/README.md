# README #
Required:
You need to have docker and compose installed on your machine.

How to Start/Stop:
After unzip to a folder (say, d:\deepscan):
	1. Start docker daemon, if not already.
	2. cd D:\deepscan
	3. Run the command:  run.cmd  ( or run.sh for *inx OS)
	 		. First time can take upto 10 minutes while all docker images are pulled/built.
			. Open your browser and navigate to http://localhost:5021
			. You can perform various scans on this web page. 
	4. To stop the server: stop.cmd  (or stop.sh for *inx)