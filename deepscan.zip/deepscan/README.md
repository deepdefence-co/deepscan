# README #



Required:
--------
1. Run the software on a Windows or Apple Mac OS with atleast 4GB RAM and 10GB free space on hard drive.
2. You need to have Docker and Compose installed on the machine. You may download it from https://docs.docker.com/compose/install/

How to Start/Stop:
-----------------
After unzip to a folder (say, d:\deepscan):
	1. Start docker daemon on your machine, if not already.
	2. cd D:\deepscan
	3. Run the command:
		For Windows:  run.cmd 
		For Mac:
			chmod +x run.sh
			./run.sh				
	Note: First time can take upto 10 minutes while all docker images are pulled/built.
	5. Open your browser and navigate to http://<your_machine_ip>:5021. You can perform various security tests using the UI.
	6. To stop: stop.cmd  (or ./stop.sh for Mac)

